/* [TODO] Step 1: Parse the Data
    Parse the data contained in file, multilingual_mobile_app_reviews_2025.csv, into a JavaScript object
    using the modules fs and papaparse. According to Kaggle, there should be 2514 reviews.
*/

/* [TODO] Step 2: Clean the Data
    Filter out every data record with null column values, ignore null gender values.
    Convert review_id, user_id, num_helpful_votes, and user_age to Integer
    Convert rating to Float
    Convert review_date to Date
*/

/* [TODO] Step 3: Sentiment Analysis 
    Write a function, labelSentiment, that takes in a rating as an argument 
    and outputs 'positive' if rating is greater than 4, negative is rating is below 2, and neutral if it is between 2 and 4.
    Then, print out a summary of the positive, neutral, and negative ratings separated by app, and then by language.
*/

/* [TODO] Step 4: Statistical Analysis 
    Answer the following questions:
        What is the most reviewed app in this dataset, and how many reviews does it have?
        For the most reviewed app, what is the most commonly used device?
        For the most reviewed app, what the average star rating (out of 5.0)?
*/
let mostReviews;
let mostReviewedApp;
let mostUsedDevice;
let avgStarRating;