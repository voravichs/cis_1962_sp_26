function add(a, b) {
    return a + a;
}

module.exports = {
    add
}