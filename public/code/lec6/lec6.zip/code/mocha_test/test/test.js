const assert = require('assert');
const { add } = require('../index.js');
describe('add', function() {
  it('adds two numbers', function() {
    assert.strictEqual(add(2, 3), 5);
  });
});
