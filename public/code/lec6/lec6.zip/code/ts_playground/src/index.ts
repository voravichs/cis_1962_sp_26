function padLeft(value: string, padding: number | string): string {
  if (typeof padding === "number") {
    return " ".repeat(padding) + value;
  } else {
    return padding + value;
  }
}

function makeImportant(arr: string[]) {
  return arr.map((item) => `${item.toUpperCase()}!!!`);
}


console.log(padLeft("hello", 5));
console.log(padLeft("hello", ">>> "));
