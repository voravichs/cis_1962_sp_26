import dad_jokes from "dad_jokes_package"

dad_jokes().then(joke => console.log(joke));