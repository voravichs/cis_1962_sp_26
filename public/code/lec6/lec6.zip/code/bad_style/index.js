let unused = 0;

for (let i = 0; i < 10; i--) {
    console.log('hello world');
}

// const space = " "
// console.log("hello" + space + "world")
// console.log(`hello${space}world`)

// function add(a, b) {return a + a;}

// export function add(a, b) {
//     return a + a;
// }

module.exports = {
    add,
};
