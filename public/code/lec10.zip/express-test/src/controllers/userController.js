// In this file we can recieve the request and output the responses from Express, and call service functions.
import { getUserDataService, setUserDataService } from '../services/userService.js';

export async function getUser(req, res) {
  const user = req.user;
  const data = await getUserDataService(user);
  res.json({ msg: `Got user: ${user}`, data });
}

export async function createUser(req, res) {
  const user = req.user;
  await setUserDataService(user, req.body);
  res.json({ msg: `Created user ${user}` });
}