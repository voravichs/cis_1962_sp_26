// In this file we can directly interface with the database we are using (Redis)
import redisClient from '../redisClient.js';

export async function getUserData(user) {
  const str = await redisClient.get(`${user}:data`);
  return str ? JSON.parse(str) : null;
}

export async function setUserData(user, data) {
  await redisClient.set(`${user}:data`, JSON.stringify(data));
}