// In this file we can apply business logic, like performing validation or data transformation
import { getUserData, setUserData } from '../DAO/userDAO.js';

export async function getUserDataService(user) {
  return getUserData(user);
}

export async function setUserDataService(user, data) {
  return setUserData(user, data);
}