import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || '4fc38efabfd1b5f60776d9959603f0d4';

export function generateToken(user) {
  return jwt.sign({ user }, JWT_SECRET, { expiresIn: '24h' });
}

export function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.status(401).json({ error: 'Authorization header missing' });

  const [scheme, token] = authHeader.split(' ');
  if (scheme !== 'Bearer' || !token) return res.status(401).json({ error: 'Malformed authorization header' });

  jwt.verify(token, JWT_SECRET, (err, payload) => {
    if (err) return res.status(401).json({ error: 'Token invalid or expired' });
    if (!payload.user) return res.status(401).json({ error: 'Token missing user information' });
    req.user = payload.user;
    next();
  });
}