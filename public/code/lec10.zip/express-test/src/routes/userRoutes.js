// In this file we can define the main routes of the backend, and apply middleware like authentication.
import { Router } from 'express';
import { getUser, createUser } from '../controllers/userController.js';
import { authenticateToken } from '../auth.js';

const router = Router();

router.use(authenticateToken);
router.get('/', getUser);
router.post('/', createUser);

export default router;