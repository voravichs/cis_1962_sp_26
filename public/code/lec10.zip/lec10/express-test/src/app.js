import express from 'express';
import userRoutes from './routes/userRoutes.js';
import { generateToken } from './auth.js';

const app = express();

app.use(express.json());
app.use('/user', userRoutes);

app.post('/login', (req, res) => {
  const { user } = req.body;
  if (user) { // hard-coded to pass, should verify that user credentials are correct!
    const token = generateToken(user);
    return res.json({ token });
  } 
  res.status(401).json({ error: 'Invalid credentials' });
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});