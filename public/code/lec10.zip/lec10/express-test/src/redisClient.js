// In order to use this client, you have to fill in your credentials in createClient after setting up a database in Redis Cloud!
import { createClient } from 'redis';

const client = createClient({
    username: '...',
    password: '...',
    socket: {
        host: '...',
        port: ...
    }
});

client.connect().catch(console.error);
client.on('error', err => console.log('Redis Client Error', err));

export default client;

