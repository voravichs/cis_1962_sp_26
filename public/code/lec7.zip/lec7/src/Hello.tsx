type HelloProps = {
    hello_name: string
}

const Hello = ({hello_name}: HelloProps)  => {
    return <> Hello, {hello_name}!</>
}

export default Hello;