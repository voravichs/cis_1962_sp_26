document.getElementById('dark-mode').addEventListener('click', function() {
    let allSections = document.querySelectorAll('section');
    for (let section of allSections) {
        section.classList.toggle('dark');
    }
});

 document.getElementById('change-name-btn').addEventListener('click', function() {
    const newName = document.getElementById('name-input').value;
    document.getElementById('profile-name').textContent = newName;
});

document.getElementById('submit-form').addEventListener('submit', function(event) {
    event.preventDefault();
})