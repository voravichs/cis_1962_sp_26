import { useEffect } from "react";
import { onFCP, onLCP, onINP} from "web-vitals";

function sendToAnalytics(name: string, value: number) {
  console.log('Web Vitals Metric:', name, value);
}

export default function WebVitalsMonitor() {
  useEffect(() => {
    onFCP(metric => sendToAnalytics('FCP', metric.value));
    onLCP(metric => sendToAnalytics('LCP', metric.value));
    onINP(metric => sendToAnalytics('INP', metric.value))
  }, []);
  return null; 
}