var R=require("../../chunks/[turbopack]_runtime.js")("server/app/seed/route.js")
R.c("server/chunks/node_modules_01223e26._.js")
R.c("server/chunks/[root-of-the-server]__305a8501._.js")
R.c("server/chunks/_next-internal_server_app_seed_route_actions_b7ff5a0b.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/seed/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/seed/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
