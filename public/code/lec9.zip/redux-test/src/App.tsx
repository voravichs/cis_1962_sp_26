import { useSelector, useDispatch } from "react-redux";
import type { RootState, AppDispatch } from "./redux/store";
import { increment, decrement } from "./redux/counterSlice";
import MyForm from "./MyForm";

function App() {
  const count = useSelector((state: RootState) => state.counter.value);
  const dispatch = useDispatch<AppDispatch>();

  return (
    <div style={{ padding: 40 }}>
      <h1>Redux Toolkit + React</h1>
      <p>Count: {count}</p>
      <button onClick={() => dispatch(increment())}> + </button>
      <button onClick={() => dispatch(decrement())}> – </button>
      <MyForm/>
    </div>
  );
}

export default App
