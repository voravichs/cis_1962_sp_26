import { useForm } from "react-hook-form";
import type { SubmitHandler } from "react-hook-form";

type FormData = {
  name: string;
  email: string;
};

const MyForm = () => {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>();

  const onSubmit: SubmitHandler<FormData> = (data) => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <input {...register('name', { required: true, minLength: 8 })} />
      {errors.name && <span>Name required</span>}
      <input type="email" {...register('email')} />
      <button type="submit">Submit</button>
    </form>
  );
}

export default MyForm;