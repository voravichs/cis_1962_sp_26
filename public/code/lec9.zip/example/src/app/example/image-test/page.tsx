import Image from 'next/image';

export default function Page() {
  return (
    <Image
      src="/red-panda.png"
      width={400}
      height={400}
      alt="pixel red panda"
    />
  )
}