export default function Page() {
  return (
    <h1 className="text-5xl font-extrabold text-white drop-shadow-lg">My name is Voravich!</h1>
  )
}