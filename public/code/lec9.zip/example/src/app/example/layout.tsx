import Link from "next/link";

const navLinks = [
  { name: "Home", href: "/" },
  { name: "About", href: "/example/about" },
  { name: "Products", href: "/products" },
  { name: "Contact", href: "/contact" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <>
        <nav className="w-full bg-white border-b shadow">
            <div className="max-w-7xl mx-auto px-4 flex h-16 items-center justify-between">
                {/* Logo or title */}
                <Link href="/" className="text-xl font-bold text-blue-600 hover:text-blue-800">
                MyApp
                </Link>
                {/* Navigation Links */}
                <ul className="flex space-x-6">
                {navLinks.map((link) => (
                    <li key={link.href}>
                    <Link
                        href={link.href}
                        className="text-gray-700 hover:text-blue-600 font-medium transition"
                    >
                        {link.name}
                    </Link>
                    </li>
                ))}
                </ul>
            </div>
        </nav>
        <div className="min-h-screen bg-linear-to-r from-pink-500 via-red-500 to-yellow-500 flex items-center justify-center">{children}</div>
    </>
    
  );
}