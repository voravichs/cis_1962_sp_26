type PageProps = { params: { userId: string } };

async function getUser(id: string) {
  return { name: `User #${id}`, id };
}

export default async function Page({params}: PageProps) {
  const { userId } = await params
  const product = await getUser(userId);

  return (
    <div>
      <h1>{product.name}</h1>
      <p>User ID: {product.id}</p>
    </div>
  );
}