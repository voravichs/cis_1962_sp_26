import { Silkscreen } from 'next/font/google';

const silkscreen = Silkscreen({
  subsets: ['latin'],
  weight: ['400', '700'],
});

export default function Page() {
  return (
    <div className={`${silkscreen.className} text-6xl`}>Cool font, bro :D</div>
  )
}