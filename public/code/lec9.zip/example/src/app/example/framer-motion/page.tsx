"use client";
import { motion } from "framer-motion";

const demos = [
  {
    name: "Fade In",
    demo: (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="h-full w-full flex items-center justify-center"
      >
        Fade In
      </motion.div>
    ),
  },
  {
    name: "Scale Up",
    demo: (
      <motion.div
        initial={{ scale: 0.5 }}
        animate={{ scale: 1 }}
        transition={{ duration: 1 }}
        className="h-full w-full flex items-center justify-center"
      >
        Scale Up
      </motion.div>
    ),
  },
  {
    name: "Slide In (X)",
    demo: (
      <motion.div
        initial={{ x: -80, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 1 }}
        className="h-full w-full flex items-center justify-center"
      >
        Slide X
      </motion.div>
    ),
  },
  {
    name: "Slide In (Y)",
    demo: (
      <motion.div
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1 }}
        className="h-full w-full flex items-center justify-center"
      >
        Slide Y
      </motion.div>
    ),
  },
  {
    name: "Spring Bounce",
    demo: (
      <motion.div
        initial={{ y: -80 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 200 }}
        className="h-full w-full flex items-center justify-center"
      >
        Spring
      </motion.div>
    ),
  },
  {
    name: "Loop Spin",
    demo: (
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
        className="h-full w-full flex items-center justify-center"
      >
        🌀
      </motion.div>
    ),
  },
  {
    name: "Pulse",
    demo: (
      <motion.div
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ repeat: Infinity, duration: 1.2 }}
        className="h-full w-full flex items-center justify-center"
      >
        Pulse
      </motion.div>
    ),
  },
  {
    name: "Hover Grow",
    demo: (
      <motion.div
        whileHover={{ scale: 1.2, backgroundColor: "#FDE68A", color: "#B45309" }}
        className="h-full w-full flex items-center justify-center transition-colors"
      >
        Hover Me
      </motion.div>
    ),
  },
  {
    name: "Tap Shrink",
    demo: (
      <motion.div
        whileTap={{ scale: 0.8, rotate: -5, backgroundColor: "#FCA5A5" }}
        className="h-full w-full flex items-center justify-center transition-colors"
      >
        Tap Me
      </motion.div>
    ),
  },
  {
    name: "Draggable",
    demo: (
      <motion.div
        drag
        dragConstraints={{ top: -20, bottom: 20, left: -20, right: 20 }}
        className="h-full w-full flex items-center justify-center cursor-grab"
      >
        Drag me
      </motion.div>
    ),
  },
  {
    name: "Color Change",
    demo: (
      <motion.div
        animate={{ backgroundColor: "#A7F3D0", color: "#065F46" }}
        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
        className="h-full w-full flex items-center justify-center rounded"
      >
        Color
      </motion.div>
    ),
  },
  {
    name: "Delay & Fade",
    demo: (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1.1 }}
        className="h-full w-full flex items-center justify-center"
      >
        Delayed
      </motion.div>
    ),
  },
  {
    name: "3D Rotate",
    demo: (
      <motion.div
        animate={{ rotateY: 360 }}
        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        className="h-full w-full flex items-center justify-center"
        style={{ perspective: 200 }}
      >
        3D 🔵
      </motion.div>
    ),
  },
  {
    name: "Sequential",
    demo: (
      <motion.div
        initial={{ x: -50, opacity: 0 }}
        animate={{ x: [0, 30, 0], opacity: [0, 1, 1] }}
        transition={{ duration: 1.5 }}
        className="h-full w-full flex items-center justify-center"
      >
        Sequence
      </motion.div>
    ),
  },
  {
    name: "Fade Out on Hover",
    demo: (
      <motion.div
        whileHover={{ opacity: 0.3, scale: 0.8 }}
        className="h-full w-full flex items-center justify-center"
      >
        Bye!
      </motion.div>
    ),
  },
  {
    name: "Shake",
    demo: (
      <motion.div
        animate={{ x: [0, -10, 10, -10, 10, 0] }}
        transition={{
          repeat: Infinity,
          duration: 1.2,
          repeatType: "reverse",
          ease: "linear",
        }}
        className="h-full w-full flex items-center justify-center"
      >
        Shake
      </motion.div>
    ),
  },
];

export default function Page() {
  return (
    <div className="min-h-screen p-8 text-black">
      <h1 className="text-3xl font-bold text-center mb-10 text-white">
        Framer Motion Animation Gallery
      </h1>
      <h1 className="text-xl text-center mb-10 text-white">
        Reload the see some entrance animations!
      </h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
        {demos.map((item, i) => (
          <div
            key={i}
            className="h-32 rounded-lg shadow-lg bg-white flex flex-col items-center justify-center p-3"
          >
            <div className="h-16 flex-1 w-full flex items-center justify-center">{item.demo}</div>
            <div className="text-xs text-gray-500 mt-2">{item.name}</div>
          </div>
        ))}
      </div>
    </div>
  );
}