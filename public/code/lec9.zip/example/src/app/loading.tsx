export default function Loading() {
  return (
    <div className="flex min-h-screen items-center justify-center text-2xl">
      Loading products...
    </div>
  );
}