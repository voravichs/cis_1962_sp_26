(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_7f91881d._.js",
  "static/chunks/src_app_example_framer-motion_page_tsx_9ec70280._.js"
],
    source: "dynamic"
});
