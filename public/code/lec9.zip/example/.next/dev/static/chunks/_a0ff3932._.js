(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d83fa6eb._.js",
  "static/chunks/59315_next_dist_compiled_react-dom_7c4e7705._.js",
  "static/chunks/59315_next_dist_compiled_react-server-dom-turbopack_7b06caa0._.js",
  "static/chunks/59315_next_dist_compiled_next-devtools_index_3985dff0.js",
  "static/chunks/59315_next_dist_compiled_1bc75b2b._.js",
  "static/chunks/59315_next_dist_client_d20989b3._.js",
  "static/chunks/59315_next_dist_623c852c._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
