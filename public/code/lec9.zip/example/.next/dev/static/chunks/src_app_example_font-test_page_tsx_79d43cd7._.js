(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[next]_internal_font_google_silkscreen_fb44a526_module_3c3f6978.css"
],
    source: "dynamic"
});
