module.exports = [
"[project]/.next-internal/server/app/example/users/[userId]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_example_users_%5BuserId%5D_page_actions_d55a7060.js.map