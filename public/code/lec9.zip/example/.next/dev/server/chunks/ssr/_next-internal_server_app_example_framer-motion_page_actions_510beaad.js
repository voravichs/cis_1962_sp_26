module.exports = [
"[project]/.next-internal/server/app/example/framer-motion/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_example_framer-motion_page_actions_510beaad.js.map