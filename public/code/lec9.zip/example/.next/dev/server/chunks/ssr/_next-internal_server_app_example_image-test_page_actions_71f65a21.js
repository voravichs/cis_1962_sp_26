module.exports = [
"[project]/.next-internal/server/app/example/image-test/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_example_image-test_page_actions_71f65a21.js.map