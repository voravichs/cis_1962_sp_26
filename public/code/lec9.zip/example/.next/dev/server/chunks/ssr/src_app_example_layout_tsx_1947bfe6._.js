module.exports = [
"[project]/src/app/example/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Layout
]);
function Layout({ children }) {}
}),
];

//# sourceMappingURL=src_app_example_layout_tsx_1947bfe6._.js.map