module.exports = [
"[project]/.next-internal/server/app/example/about/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_example_about_page_actions_3049479d.js.map