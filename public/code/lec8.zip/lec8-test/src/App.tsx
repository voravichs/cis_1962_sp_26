import './App.css'
import { Home, ErrorTwoParents, ErrorRequiredTypes, ErrorLists, Bubbling, BatchAsync, InfiniteEffect} from "./Routes/Routes"

import { Routes, Route, BrowserRouter } from 'react-router-dom';

/**
 * Fix all errors before rendering!
 */
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/error-two-parents' element={<ErrorTwoParents title={"Error"} description={"Fix this component by wrapping everything in one parent element!"}/>}/>
        <Route path='/error-req-types' element={<ErrorRequiredTypes/>}/>
        <Route path='/error-lists' element={<ErrorLists/>}/>
        <Route path='/bubbling' element={<Bubbling/>}/>
        <Route path='/batch-async' element={<BatchAsync/>}/>
        <Route path='/infinite' element={<InfiniteEffect search={2}/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default App
