import { useState } from "react";

const BatchAsync = () => {
    const [count, setCount] = useState(0);

    function handleAlertAdd() {
        setCount(count + 1);
        alert(count)
    }

    return (
        <>
            <p>{count}</p>
            <button onClick={handleAlertAdd}>Add with alert</button>
        </>
    )
}

export default BatchAsync;