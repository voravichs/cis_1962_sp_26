import reactLogo from '../assets/react.svg'
import viteLogo from '/vite.svg'
import { Link } from 'react-router-dom'

const Home = () => {

  return (
    <>
      <div className='flex justify-center'>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <ul className='my-4 flex flex-col gap-4'>
        <Link to={'/error-two-parents'} className='bg-white border-2 rounded hover:border-cyan-500 p-2'>Error: Two Parents</Link>
        
        <Link to={'/error-req-types'} className='bg-white border-2 rounded hover:border-cyan-500 p-2'>Error: Required Types</Link>

        <Link to={'/error-lists'} className='bg-white border-2 rounded hover:border-cyan-500 p-2'>Error: List Rendering</Link>

        <Link to={'/bubbling'} className='bg-white border-2 rounded hover:border-cyan-500 p-2'>Bubbling</Link>

        <Link to={'/batch-async'} className='bg-white border-2 rounded hover:border-cyan-500 p-2'>State Batch Async Updates</Link>

        <Link to={'/infinite'} className='bg-white border-2 rounded hover:border-cyan-500 p-2'>Infinite Effect</Link>
      </ul>
    </>
  )
}

export default Home
