import { useState } from "react";

const Bubbling = () => {
  const [count, setCount] = useState(0);

  function increment(e: React.MouseEvent<HTMLButtonElement>) {
    setCount(count + 1);
    e.stopPropagation();
  }

  return (
    <div
      onClick={() => setCount(count - 1)}
      style={{ border: "1px solid black", padding: 20 }}
    >
      <button onClick={increment}>Increment</button>
      <p>{count}</p>
    </div>
  );
}

export default Bubbling;