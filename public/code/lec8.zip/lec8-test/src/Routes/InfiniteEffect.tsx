import { useState, useEffect } from "react";

function InfiniteEffect({ search }: { search: number}) {
  const [results, setResults] = useState([]);

  useEffect(() => {
    fetch(`https://jsonplaceholder.typicode.com/todos/${search}`)
      .then(res => res.json())
      .then(data => setResults(data));
  }, [search]);

  return (
    <ul>
      <pre>{JSON.stringify(results, null, 2)}</pre>
    </ul>
  );
}

export default InfiniteEffect;