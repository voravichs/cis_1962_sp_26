const Notice = ({ title, subtitle }: { title: string, subtitle?: string }) => (
  <section>
    <h1>{title}</h1>
    <h2>{subtitle}</h2>
  </section>
);

const Wrapper = ({ message }: { message: string }) => (
  <div>
    <Notice subtitle="This is a subtitle" title="Fixed!"/>
    {/* <Notice subtitle="This is a subtitle"/> */}
    <p>{message}</p>
  </div>
);

const ErrorRequiredTypes = () => <Wrapper message="All good!" />;

export default ErrorRequiredTypes;