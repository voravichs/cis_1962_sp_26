import { useState } from 'react'

const ErrorTwoParents = ({title, description}: {title: string, description: string}) => {
  const [liked, setLiked] = useState(false);

  return (
    <>
     <div className="bg-white p-4 rounded-lg shadow-md max-w-xs">
      <h2 className="text-lg font-bold mb-2">{title}</h2>
      <p className="text-gray-600 mb-4">{description}</p>
      <button
        className={`text-xl ${liked ? "text-red-500" : "text-gray-400"}`}
        onClick={() => setLiked((prev) => !prev)}
      >
        ❤️
      </button>
      
      <div className="text-xs text-gray-400 mt-2">Click the heart to like!</div>
    </div>
    </>
   
  )
}

export default ErrorTwoParents
