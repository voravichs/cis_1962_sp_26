const ErrorLists = () => {
  const orders = [
    { id: 101, customer: "Alice", items: ["Book", "Pen"], total: 12.9 },
    { id: 102, customer: "Bob", items: ["Notebook"], total: 4.2 },
    { id: 103, customer: "Carol", items: ["Eraser", "Book"], total: 3.3 },
  ];

  return (
    <section>
      <h2 className="font-bold text-lg">Order History</h2>
      <ul>
        {orders.map(order => (
          <li className="mb-3" key={order.id}>
            <div>Customer: {order.customer}</div>
            <ul>
                {order.items.map(item => (
                    <li key={item}>
                        <span>{item}</span>
                    </li>
              ))}
            </ul>
            <p>Total: ${order.total}</p>
          </li>
          
        ))}
      </ul>
    </section>
  );
}

export default ErrorLists;