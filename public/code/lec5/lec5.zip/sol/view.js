/**
 * View: Abstracts away ALL of the dynamic visual elements in order to 
 * keep all visual logic in one place.
 */
export class ShapeView {
    constructor(canvas, controls) {
        this.canvas = canvas;
        this.controls = controls;
        this.shapeTypeInput = null;
        // Properties for methods from controller
        this.onAddShape = null;
        this.onCanvasClick = null;
        this.onShapeClick = null;
    }

    // Renders the controls within the controls id element.
    renderControls() {
        this.controls.innerHTML = `
        <label>
            Type:
            <select id="shape-type">
            <option value="rectangle">Rectangle</option>
            <option value="circle">Circle</option>
            </select>
        </label>
        <label>
            X: <input type="number" id="shape-x" value="50" min="0" max="600">
        </label>
        <label>
            Y: <input type="number" id="shape-y" value="50" min="0" max="400">
        </label>
        <span id="size-inputs"></span>
        <label>
            Color:
            <input type="color" id="shape-color" value="#e74c3c">
        </label>
        <button id="add-shape">Add Shape</button>
        `;
        // Get the size input and initially update it. 
        // Then keep an event listener to update whenever options change
        this.shapeTypeInput = this.controls.querySelector('#shape-type');
        this.updateSizeInputs();
        this.shapeTypeInput.addEventListener('change', () => this.updateSizeInputs());

        // Click listener for add shape button, links to onAddShape in controller
        this.controls.querySelector('#add-shape').addEventListener('click', () => {
            if (this.onAddShape) {
                const x = Number(this.controls.querySelector('#shape-x').value);
                const y = Number(this.controls.querySelector('#shape-y').value);
                const color = this.controls.querySelector('#shape-color').value;
                let shapeParams = { type: this.shapeTypeInput.value, x, y, color };
                if (shapeParams.type === 'rectangle') {
                    shapeParams.width = Number(this.controls.querySelector('#shape-width').value);
                    shapeParams.height = Number(this.controls.querySelector('#shape-height').value);
                } else if (shapeParams.type === 'circle') {
                    shapeParams.radius = Number(this.controls.querySelector('#shape-radius').value);
                }
                this.onAddShape(shapeParams);
            }
        });
    }

    // Update the size inputs for either rectangles or circles
    updateSizeInputs() {
        const sizeInputs = this.controls.querySelector('#size-inputs');
        if (this.shapeTypeInput.value === 'rectangle') {
            sizeInputs.innerHTML = `
                <label>
                    Width: <input type="number" id="shape-width" value="80" min="10" max="400">
                </label>
                <label>
                    Height: <input type="number" id="shape-height" value="40" min="10" max="400">
                </label>
            `;
        } else if (this.shapeTypeInput.value === 'circle') {
            sizeInputs.innerHTML = `
                <label>
                    Radius: <input type="number" id="shape-radius" value="30" min="5" max="200">
                </label>
            `;
        }
    }

    // Render the canvas of shapes.
    renderCanvas(shapes) {
        // Initially clears the canvas, then adds the shapes from the model onto the canvas.
        this.canvas.innerHTML = '';
        shapes.forEach((shape, idx) => {
            let div = document.createElement('div');
            div.className = 'shape';
            div.style.left = `${shape.x}px`;
            div.style.top = `${shape.y}px`;
            div.style.background = shape.color;

            if (shape.constructor.name === "Rectangle") {
                div.style.width = `${shape.width}px`;
                div.style.height = `${shape.height}px`;
                div.style.borderRadius = '6px';
            } else if (shape.constructor.name === "Circle") {
                div.style.width = div.style.height = `${shape.radius * 2}px`;
                div.style.borderRadius = '50%';
            }

            if (shape.selected) div.classList.add('selected');

            // Click listener for shapes, links to onShapeClick in controller
            div.addEventListener('click', e => {
                e.stopPropagation();
                if (this.onShapeClick) this.onShapeClick(idx);
            });

            this.canvas.appendChild(div);
        });

        // Click listener for canvas, links to onCanvasClick in controller
        this.canvas.addEventListener('click', () => {
            if (this.onCanvasClick) this.onCanvasClick();
        }, { once: true });
    }
}