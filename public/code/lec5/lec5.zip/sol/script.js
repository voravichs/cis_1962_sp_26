/**
 * This runner script handles initialization of the app and passes DOM items
 * like the controls and canvas to the view.
 */
import { ShapeModel } from './model.js';
import { ShapeView } from './view.js';
import { ShapeController } from './controller.js';

const controls = document.getElementById('controls');
const canvas = document.getElementById('canvas');
const model = new ShapeModel();
const view = new ShapeView(canvas, controls);
const controller = new ShapeController(model, view);
controller.initialize();