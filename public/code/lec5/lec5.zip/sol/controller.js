/**
 * Controller: handles adding shapes to a canvas. 
 * Update the model and renders shapes when prompted by user input.
 * This controller makes it much easier to define how model and view will interact.
 * Notice most of these methods will update both the view by rendering and the model by updating the shapes array there.
 */
export class ShapeController {
    constructor(model, view) {
        this.model = model;
        this.view = view;
        // Connect view to controller by adding controller functions to view
        this.view.onAddShape = params => this.handleAddShape(params);
        this.view.onCanvasClick = () => this.handleDeselect();
        this.view.onShapeClick = idx => this.handleSelect(idx);
    }

    // Initially add 2 shapes for demonstration
    initialize() {
        import('./model.js').then(({Rectangle, Circle}) => {
            this.model.addShape(new Rectangle(40, 50, 100, 40, "#27ae60"));
            this.model.addShape(new Circle(200, 120, 30, "#2980b9"));
            this.view.renderControls();
            this.#render();
        });
    }

    // Add a shape depending on what parameter is passed in.
    // An event listener in View's renderControls method listens for a button click on the add shape button
    handleAddShape(params) {
        import('./model.js').then(({Rectangle, Circle}) => {
            let shape;
            if (params.type === 'rectangle') {
                shape = new Rectangle(params.x, params.y, params.width, params.height, params.color);
            } else if (params.type === 'circle') {
                shape = new Circle(params.x, params.y, params.radius, params.color);
            }
            this.model.addShape(shape);
            this.#render();
        });
    }

    // Select shape onShapeClick
    // An event listener in View's renderCanvas method listens for clicks on shapes
    handleSelect(idx) {
        this.model.selectShape(idx);
        this.#render();
    }

    // Unselect shape onCanvasClick
    // An event listener in View's renderCanvas method listens for clicks on the canvas
    handleDeselect() {
        this.model.deselectAll();
        this.#render();
    }

    // A private method that renders the canvas.
    #render() {
        this.view.renderCanvas(this.model.getShapes());
    }
}