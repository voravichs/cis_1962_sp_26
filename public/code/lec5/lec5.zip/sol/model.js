/**
 * Model: We define some classes to represent differnt types of shapes.
 * Each shape has an xy coordinate and a color, but a rectangle has width and height, while a circle has a radius.
 */
export class Shape {
    constructor(x, y, color) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.selected = false;
    }
    select() { this.selected = true; }
    deselect() { this.selected = false; }
}

export class Rectangle extends Shape {
    constructor(x, y, width, height, color) {
        super(x, y, color);
        this.width = width;
        this.height = height;
    }
}

export class Circle extends Shape {
    constructor(x, y, radius, color) {
        super(x, y, color);
        this.radius = radius;
    }
}

/**
 * ShapeModel: Manages the collection of shapes on screen
 */
export class ShapeModel {
    constructor() {
        this.shapes = [];
        this.selectedShapeIndex = null;
    }

    addShape(shape) {
        this.shapes.push(shape);
        this.selectedShapeIndex = this.shapes.length - 1;
    }

    getShapes() {
        return this.shapes;
    }

    getSelectedShape() {
        return this.selectedShapeIndex !== null ? this.shapes[this.selectedShapeIndex] : null;
    }

    selectShape(index) {
        this.shapes.forEach(s => s.deselect());
        this.selectedShapeIndex = index;
        if (index !== null) this.shapes[index].select();
    }
    
    deselectAll() {
        this.shapes.forEach(s => s.deselect());
        this.selectedShapeIndex = null;
    }
}