# API Documentation

This project provides a RESTful API for managing Pokemon data.

## Base URL

`https://qcknfszkz7.execute-api.us-east-1.amazonaws.com/pokedex`

## Pokemon Endpoints

### List Pokemon

Get a paginated list of Pokemon.

**Endpoint**: `GET /pokemon/`

**Query Parameters**:
- `limit` (number, optional): Maximum number of Pokemon to return
- `offset` (number, optional): Number of Pokemon to skip

**Response**: `Pokemon[]`

**Example Requests**:
```
GET https://qcknfszkz7.execute-api.us-east-1.amazonaws.com/pokedex/pokemon
```
```
GET https://qcknfszkz7.execute-api.us-east-1.amazonaws.com/pokedex/pokemon?limit=10&offset=10
```

### Get Pokemon by Name OR ID

Get detailed information about a specific Pokemon. 

**Endpoint**: `GET /pokemon/:identifier`

**Path Parameters**:
- `identifier` (string, required): The name OR ID of the Pokemon

**Response**: `Pokemon`

**Example Request**:
```
GET https://qcknfszkz7.execute-api.us-east-1.amazonaws.com/pokedex/pokemon/pikachu
```

## Type Endpoints

### List All Types

Get a list of all types available for the pokemon in the API

**Endpoint**: `GET /pokemon/types`

**Response**: `string[]` (array of all types)

**Example Request**:
```
GET https://qcknfszkz7.execute-api.us-east-1.amazonaws.com/pokedex/pokemon/types
```

### List All Pokemon of a certain type

Get a list of all pokemon with a specified type

**Endpoint**: `GET /pokemon/types/:type`

**Path Parameters**:
- `type` (string, required): type you want to search for

**Query Parameters**:
- `limit` (number, optional): Maximum number of Pokemon to return
- `offset` (number, optional): Number of Pokemon to skip

**Response**: `Pokemon[]`

**Example Requests**:
```
GET https://qcknfszkz7.execute-api.us-east-1.amazonaws.com/pokedex/pokemon/types/grass
```
```
GET https://qcknfszkz7.execute-api.us-east-1.amazonaws.com/pokedex/pokemon/types/grass?limit=10&offset=10
```

## Type Definitions

### Pokemon

```typescript
{
  id: number;
  name: string;
  types: PokemonType[];
  sprite: string;       // a link to the image that can be used for display
  flavor_text: string;
}
```

### PokemonType

```typescript
{
  name: string;        // Type name in uppercase (e.g., "FIRE", "WATER")
  color: string;       // Hex color code for the type
}
```