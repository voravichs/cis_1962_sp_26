export type PokemonType = {
  name: string; // Type name in uppercase (e.g., "FIRE", "WATER")
  color: string; // Hex color code for the type
};

export type Pokemon = {
  id: number;
  name: string;
  types: PokemonType[];
  sprite: string; // a link to the image that can be used for display
  flavor_text: string;
};
