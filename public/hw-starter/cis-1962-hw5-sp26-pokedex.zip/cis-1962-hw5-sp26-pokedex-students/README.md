# Homework 5: Pokedex Reflection

## Are there any extra installation steps to run this project other than 'npm install' and 'npm run dev'?

## How many hours did you spend working on this homework?

## What challenges/roadblocks did you face during this homework?

## Did you use AI/LLM tools for this assignment? If so, please provide a transcript or document your usage extensively below. If you did use AI, please explain why you decided to use AI for the task you used it for, what you learned from the AI responses, and explain any relevant unfamiliar terms and concepts that the AI responses generated.