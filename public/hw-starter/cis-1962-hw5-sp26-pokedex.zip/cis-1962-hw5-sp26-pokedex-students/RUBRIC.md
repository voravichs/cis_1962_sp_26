# HW5 Pokedex Rubric

## Functionality

- [ ] App starts using 'npm run dev' without issue or errors after installation.
- [ ] Pokedex displays Pokemon details in a paginated list with a limit of 10 per page.
- [ ] Initial pagination starts at 1 upon booting up (with Bulbasaur as the first Pokemon shown.)
- [ ] The display for each Pokemon shows the name, sprite image, and types.
- [ ] There is a way to open a modal that also displays all the Pokemon information, including flavor text.
- [ ] There is a clear way to close the modal as well.
- [ ] Search functionality works, allowing search by name and type upon clicking the search button.
- [ ] Search results are paginated and update the pagination controls accordingly.

## UI/UX

- [ ] App is generally easy to navigate and the styling is consistent.
- [ ] App makes use of the provided colors for Pokemon types within the interface for each Pokemon display.
- [ ] The modal is visually distinct from the main page and clearly shows the Pokemon details.
- [ ] The search bar is easily identifiable and accessible.
- [ ] Pagination controls are clearly visible and easy to use.

# Code

- [ ] Final app is written in TypeScript, and runs with the Vite development server.
- [ ] Code has no TypeScript errors, warnings, or bugs.
- [ ] No 'any' types are parsed in TypeScript (unless a good reason is provided)
- [ ] Project contains at least 3 more components than the starter code provided (App.tsx and main.tsx)
- [ ] Code properly fetches data from the API and handles asynchronous operations correctly using async/await and Promises.
- [ ] Hooks and state management are used appropriately to manage the application's state and side effects.