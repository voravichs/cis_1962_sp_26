export interface Message {
    role: "user" | "model";
    content: string;
}

export interface ChatData {
    id: string;
    messages: Message[];
}

export interface ChatAPIOptions {
    baseUrl: string;
    apiKey: string;
}