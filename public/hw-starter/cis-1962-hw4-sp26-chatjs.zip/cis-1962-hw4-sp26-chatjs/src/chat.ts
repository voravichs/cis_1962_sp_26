import { chatAPI } from "./chat-api.js";
import type { Message } from "./types";

// ** TODO **
// Add your Gemini API key here
// For the sake of simplicity this is hardcoded, don't do this in normal production code!
const GEMINI_API_KEY = "GEMINI_API_KEY_HERE";
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;

/**
 * Generates a response from the Gemini API
 * @param {string[]} messages - The messages to generate a response for
 * @returns {string} - The response from the Gemini API
 */
const generateGeminiResponse = async (messages: Message[]): Promise<string | undefined> => {
    const response = await fetch(GEMINI_API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-goog-api-key": GEMINI_API_KEY
        },
        body: JSON.stringify({
            contents: messages.map(message => ({ role: message.role, parts: [{ text: message.content }] }))
        })
    });
    const data = await response.json();
    const content = data.candidates[0].content.parts[0].text;
    return content;
};

/**
 * The Chat class
 * @param {string} id - The id of the chat
 * @param {string[]} messages - The messages in the chat
 */
export class Chat {
    /**
     * The constructor for the Chat class
     * @requirements
     * - Should store the id and messages
     * @param {string} id - The id of the chat
     * @param {string[]} messages - The messages in the chat
     */
    id: string;
    messages: Message[];

    constructor({ id, messages }: { id: string; messages: Message[] }) {
        // ** TODO **
    }

    /**
     * Gets the messages in the chat
     * @usage const messages = chat.getMessages();
     * @returns {string[]} - The messages in the chat
     */
    getMessages(): Message[] {
        // ** TODO **
    }

    /**
     * Sends a message to the chat
     * @usage const messages = await chat.sendMessage("Hello, how are you?");
     * @param {string} message - The message to send
     * @returns {Promise<string[]>} - The messages in the chat, including the new messages
     */
    async sendMessage(message: string): Promise<Message[]> {
        // ** TODO **
    }

    /**
     * Saves the chat
     * @usage await chat.save();
     * @returns {Promise<void>} - The promise to save the chat
     */
    async save(): Promise<void> {
        // ** TODO **
    }
}