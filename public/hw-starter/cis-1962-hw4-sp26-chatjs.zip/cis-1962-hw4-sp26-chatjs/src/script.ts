/**
 * Main script for the chatbot application.
 * !!! NOTE !!!: some of the function headers will need to be modified to include async functions.
 * Read through the requirements for each function to figure out which ones may need to be async!
 */

import { Chat } from "./chat.js";
import { chatAPI } from "./chat-api.js";
import type { Message } from "./types";

// ** TODO **
// Initialize currentChat to a "default" id chat with no messages. 
// This will be used as a fallback if there are no chats in the chat API yet (which will be the case on the first load of the app).
let currentChat = null
let currentChatId = "default";

/**
 * Renders the messages in the chat current selected
 * @requirements
 * - Clears the chat messages area
 * - Loops through the messages and creates a div for each message
 * - Adds the appropriate classes to each message div based on the role (user or assistant)
 * - Appends each message div to the chat messages area
 * @param {{role: "user" | "assistant", content: string}[]} messages - The messages to render
 */
function renderMessages(messages: Message[]) {
    // ** TODO **
}

/**
 * Shows a typing indicator. Used when waiting for a response from the chatbot.
 * @requirements
 * - Displays a typing indicator element in the chat area
 */
function showTypingIndicator() {
    // ** TODO **
}

/**
 * Hides the typing indicator when the chatbot has responded.
 * @requirements
 * - Hides the typing indicator element in the chat area
 */
function hideTypingIndicator() {
    // ** TODO **
}

/**
 * Renders a list of chats in the sidebar.
 * @requirements
 * - Highlights the currently selected chat
 * - Creates a button for each chat that switches to that chat when clicked
 */
function renderChatList() {
    // ** TODO **
}

/**
 * Switches to a different chat
 * @requirements
 * - Fetches the chat from the chat API
 * - Renders the messages from the selected chat
 * - Renders the chat list to highlight the selected chat
 * @param {string} chatId - The id of the chat to switch to
 */
function switchToChat(chatId: string) {
    // ** TODO **
}

/**
 * Initializes the app
 * @requirements
 * - Fetch the first chat from the chat API and switch to it
 * - Fetches chat with id "default" if none exists yet (this will be the case on the first load of the app, since there are no chats yet)
 * - If no chat exists, create a new chat
 */
function initializeApp() {
    // ** TODO **
}

/**
 * Event listener for submitting a new message.
 * @requirements
 * - Prevents the default form submission behavior
 * - Gets the message from the form input (use FormData for easier type safety: https://developer.mozilla.org/en-US/docs/Web/API/FormData/FormData )
 * - Resets the form input
 * - Sends the message to the current chat
 * - Shows the typing indicator
 * - Renders the messages including the new user message
 * - Waits for the chatbot response
 * - Hides the typing indicator
 * - Renders the chat list to update any necessary information
 * - Saves the current chat to Chat API
 */
// ** TODO **

/**
 * Event listener for creating a new chat when the "New Chat" button is clicked.
 * @requirements
 * - Creates a new chat using the chat API
 * - Switches to the new chat
 */
// ** TODO **

/**
 * Event listener for clearing all chats when the "Clear Chats" button is clicked.
 * @requirements
 * - Clears the chatIds array in the chat API
 * - Renders an empty chat list
 * - Renders the empty chat area
 */
// ** TODO **

// Initializes the app
initializeApp();