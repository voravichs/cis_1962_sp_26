import { Chat } from "./chat.js";
import type { ChatData, ChatAPIOptions } from "./types";

// ** TODO ** 
// Add your API key given from your instructor here. 
// For the sake of simplicity this is hardcoded, don't do this in normal production code!
const BASE_URL = "https://cis-1962-201-sp26-hw4.onrender.com/api";
const API_KEY = "CHAT_API_KEY_HERE";

/**
 * The ChatAPI class that provides methods to interact with the chat storage API
 * @param {string} baseUrl - The base URL of the chat API
 * @param {string} apiKey - The API key for the chat API
 */
export class ChatAPI {

    /**
     * The constructor for the ChatAPI class
     * @requirements
     * - Should store the baseUrl and apiKey
     * - Should initialize an empty array to store the chatIds
     * @param {string} baseUrl - The base URL of the chat API
     * @param {string} apiKey - The API key for the chat API
     */
    baseUrl: string;
    apiKey: string;
    chatIds: string[];

    constructor({ baseUrl, apiKey }: ChatAPIOptions) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.chatIds = [];
    }

    /**
     * Fetches the chatIds from the chat API and stores them in the chatIds array
     * @usage await chatAPI.fetchChats();
     * @returns {Promise<string[]>} - The chatIds
     */
    async fetchChats(): Promise<string[]> {
        // ** TODO ** 
    }

    /**
     * Creates a new chat and stores the chatId in the chatIds array
     * @usage await chatAPI.createChat();
     * @returns {Promise<Chat>} - The new chat
     */
    async createChat(): Promise<Chat> {
        // ** TODO ** 
    }

    /**
     * Updates a chat and stores the chatId in the chatIds array
     * @usage await chatAPI.updateChat({
     *     id: "123",
     *     messages: [
     *         { role: "user", content: "Hello, how are you?" },
     *         { role: "model", content: "I'm doing great, thank you!" }
     *     ]
     * });
     * @param {Chat} chat - The chat to update
     * @returns {Promise<Chat>} - The updated chat
     */
    async updateChat(chat: Chat): Promise<ChatData> {
        // ** TODO ** 
    }

    /**
     * Gets a chat by its id
     * @usage await chatAPI.getChat("chat_id");
     * @param {string} id - The id of the chat
     * @returns {Promise<Chat>} - The chat
     */
    async getChat(id: string): Promise<Chat> {
        // ** TODO ** 
    }

    /**
     * Clears all chats from the chat API
     * @usage await chatAPI.clearChats();
     */
    async clearChats(): Promise<void> {
        // ** TODO ** 
    }
}


/**
 * Export the shared chatAPI instance
 */
export const chatAPI = new ChatAPI({
    baseUrl: BASE_URL,
    apiKey: API_KEY
});
