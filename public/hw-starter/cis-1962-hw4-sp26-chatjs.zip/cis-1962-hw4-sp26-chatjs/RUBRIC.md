# Chat

## Functionality

- [ ] User is able to send messages to the chatbot
- [ ] User is able to receive messages from the chatbot
- [ ] Chatbot remembers conversations upon page reload
- [ ] User is able to click on chats in a sidebar and switch to those chats
- [ ] User is able to create new chats with a button, and each new chat has empty messages
- [ ] User is able to delete all chats. Afterwards, the messages and the chat list should be empty save for a new "default" chat.

## Error Handling

- [ ] try/catch blocks are present in applicable methods that will fetch content
- [ ] Whenever a server error occurs, both an error is logged in the console and the user is informed of the error in the interface.

# Storage

- [ ] Messages can be stored in the Key-Value storage API
- [ ] All messages can be retrieved from the Key-Value storage API
- [ ] A messages can be retrieved by ID from the Key-Value storage API
- [ ] Messages can be updated in the Key-Value storage API
- [ ] Messages can be deleted from the Key-Value storage API

# UI/UX

- Chat
  - [ ] Send button is visible and clickable
  - [ ] Input field is visible and clickable
  - [ ] Send button is disabled when the input field is empty
  - [ ] Typing indicator is shown when the chatbot is typing
  - [ ] Chat messages are displayed in a scrollable container
  - [ ] Sender and receiver are displayed in a different color
- Rooms
  - [ ] Room list is displayed in a scrollable container
  - [ ] Room list displays the list of rooms
  - [ ] When a Room is clicked, it opens the chatroom

## Code

- [ ] Chat message lists are encapsulated in the `Chat` class
- [ ] Asynchronous programming best practices are followed, including using async/await and Promise syntax
- [ ] Makes proper use of Fetch API, providing proper methods, headers, and bodies for HTTP requests
- [ ] script.ts is written in TypeScript, and compiles to script.js within the dist folder
- [ ] Code has no TypeScript errors, warnings, or bugs
- [ ] No 'any' types are parsed in TypeScript (unless a good reason is provided)

Note: We will only style check the .ts file!