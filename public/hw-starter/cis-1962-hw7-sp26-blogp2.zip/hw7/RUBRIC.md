# HW7 Blog Part 2 Rubric

## Functionality
- Users can create accounts and login to the system
- Each user is tied to a singular blog and profile
- Users can view the blogs of all other users on the platform
- Users can create, edit, and delete their own blog posts
- Users can view comments on their blog posts and add comments to other users' posts
- Users can delete comments on their own posts

## Full Stack & Code Quality
- The frontend and backend are fully integrated and functional
- The app properly runs from the root directory with the command `npm run dev`
- User interaction with the frontend seamlessly triggers the appropriate backend routes and updates the UI accordingly
- React Router routes are properly set up and navigate to their expected pages (Home -> "/"; Login -> "/login"; Register -> "/register"; etc)
- Cookies are used for login and properly expire after 1 hour

## UI/UX
- Loading is handled and displayed for all asynchronous actions (e.g., fetching blogs, submitting posts/comments)
- UI displays errors to the user when actions fail (e.g., failed login, failed post submission)
- UI states update upon logging in and out 
    - Navbar updates upon login/logout to show appropriate links (e.g., Login/Register when logged out; Logout/Profile when logged in)
    - Home page content shows user blog on top
    - Navbar link to posts goes to the logged-in user's posts
    - User profile shows the logged-in user's profile details
- When any posts or comments are deleted or edited, the UI updates immediately to reflect the changes without needing to refresh the page
- Users are unable to access the edit/delete functionality for posts or comments that they do not own

## Reflection Questions
- The reflection questions are answered thoughtfully and thoroughly, demonstrating an understanding of security, optimization, and deployment considerations in a full-stack application