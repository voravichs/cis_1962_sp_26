export const hasToken = () => {
  return document.cookie.split(";").some((c) => c.trim().startsWith("token="));
};

export const getToken = () => {
  return document.cookie
    .split(";")
    .find((c) => c.trim().startsWith("token="))
    ?.split("=")[1];
};

export const readUsernameFromToken = () => {
  let currentUser = null;
  const token = getToken();
  if (token) {
    try {
      const payload = JSON.parse(atob(token.split(".")[1]));
      currentUser = payload.username || null;
    } catch {}
  }
  return currentUser;
};
