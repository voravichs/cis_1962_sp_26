import { useState } from "react";

interface PostCreateModalProps {
  open: boolean;
  onClose: () => void;
  onCreate: (post: { title: string; content: string }) => Promise<void>;
}

const PostCreateModal = ({ open, onClose, onCreate }: PostCreateModalProps) => {
  const [form, setForm] = useState({ title: "", content: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  if (!open) return null;

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.SubmitEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    try {
      await onCreate(form);
      setSuccess("Post created!");
      setForm({ title: "", content: "" });
      setTimeout(() => {
        setSuccess("");
        onClose();
      }, 1000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-md relative">
        <button
          className="absolute top-2 right-2 text-gray-500 hover:text-gray-700 text-3xl cursor-pointer"
          onClick={onClose}
        >
          &times;
        </button>
        <h2 className="text-2xl font-bold mb-4">Create Post</h2>
        <form onSubmit={handleSubmit}>
          <input
            className="w-full mb-2 p-2 border rounded"
            type="text"
            name="title"
            placeholder="Title"
            value={form.title}
            onChange={handleChange}
            required
          />
          <textarea
            className="w-full mb-2 p-2 border rounded"
            name="content"
            placeholder="Content"
            value={form.content}
            onChange={handleChange}
            rows={4}
            required
          />
          <button
            className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded cursor-pointer"
            type="submit"
          >
            Create Post
          </button>
          {error && <div className="text-red-500 mt-2">{error}</div>}
          {success && <div className="text-green-500 mt-2">{success}</div>}
        </form>
      </div>
    </div>
  );
};

export default PostCreateModal;
