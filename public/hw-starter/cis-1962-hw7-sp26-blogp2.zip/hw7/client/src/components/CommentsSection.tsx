import CommentCreateModal from "./CommentCreateModal";

interface Comment {
  commentId: string;
  postId: string;
  content: string;
  username: string;
  postAuthor: string;
  createdAt: string;
}

interface CommentsSectionProps {
  comments: Comment[];
  modalOpen: boolean;
  setModalOpen: (open: boolean) => void;
  handleCreateComment: (content: string) => Promise<void>;
  canDeleteComment?: boolean;
  handleDeleteComment?: (commentId: string) => void;
}

const CommentsSection = ({
  comments,
  modalOpen,
  setModalOpen,
  handleCreateComment,
  canDeleteComment,
  handleDeleteComment,
}: CommentsSectionProps) => (
  <div className="mt-6">
    <h3 className="text-lg font-semibold mb-2">Comments</h3>
    <button
      className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded mb-4 cursor-pointer"
      onClick={() => setModalOpen(true)}
    >
      Create Comment
    </button>
    <CommentCreateModal
      open={modalOpen}
      onClose={() => setModalOpen(false)}
      onCreate={handleCreateComment}
    />
    {comments.length === 0 ? (
      <div className="text-gray-400">No comments yet.</div>
    ) : (
      <ul>
        {comments.map((comment, idx) => (
          <li
            key={comment.commentId || idx}
            className="mb-3 border-b border-gray-300 pb-2 relative"
          >
            <div className="text-gray-800">{comment.content}</div>
            <div className="text-xs text-gray-500">
              By {comment.username} on{" "}
              {new Date(comment.createdAt).toLocaleString()}
            </div>
            {canDeleteComment && handleDeleteComment && (
              <button
                className="absolute top-2 right-2 px-2 py-1 bg-red-500 hover:bg-red-600 text-white rounded text-xs cursor-pointer"
                onClick={() => handleDeleteComment(comment.commentId!)}
              >
                Delete
              </button>
            )}
          </li>
        ))}
      </ul>
    )}
  </div>
);

export default CommentsSection;
