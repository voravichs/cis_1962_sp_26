import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { hasToken, readUsernameFromToken } from "../util/util";

const Navbar = () => {
  const navigate = useNavigate();
  const [loggedIn, setLoggedIn] = useState(hasToken());
  const currentUser = readUsernameFromToken();

  useEffect(() => {
    const interval = setInterval(() => {
      setLoggedIn(hasToken());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <nav className="bg-blue-600 p-4 flex justify-center space-x-4 shadow">
      <Link
        to="/"
        className="text-white font-semibold hover:bg-blue-700 px-3 py-2 rounded transition"
      >
        Home
      </Link>
      {!loggedIn ? (
        <>
          <Link
            to="/register"
            className="text-white font-semibold hover:bg-blue-700 px-3 py-2 rounded transition"
          >
            Register
          </Link>
          <Link
            to="/login"
            className="text-white font-semibold hover:bg-blue-700 px-3 py-2 rounded transition"
          >
            Login
          </Link>
        </>
      ) : (
        <>
          <div
            className="text-white font-semibold hover:bg-blue-700 px-3 py-2 rounded transition cursor-pointer"
            onClick={() => {
              document.cookie =
                "token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
              if (window.location.pathname === "/") {
                window.location.reload();
              } else {
                navigate("/");
              }
            }}
          >
            Logout
          </div>
          <span className="mx-8 border-l border-white h-10 inline-block align-middle"></span>
          <span className="text-white font-semibold px-3 py-2 rounded transition">
            Logged in as: {currentUser}
          </span>
          <span className="mx-8 border-l border-white h-10 inline-block align-middle"></span>
          <Link
            to="/profile"
            className="text-white font-semibold hover:bg-blue-700 px-3 py-2 rounded transition"
          >
            Profile
          </Link>
          <Link
            to={`/posts/${currentUser ?? ""}`}
            className="text-white font-semibold hover:bg-blue-700 px-3 py-2 rounded transition"
          >
            Posts
          </Link>
        </>
      )}
    </nav>
  );
};

export default Navbar;
