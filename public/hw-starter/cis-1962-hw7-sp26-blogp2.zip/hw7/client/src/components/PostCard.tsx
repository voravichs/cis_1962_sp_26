import { Link } from "react-router-dom";

interface PostCardProps {
  post: {
    id: string;
    title: string;
    content: string;
    username: string;
    createdAt: string;
  };
  user?: string;
  onDelete?: () => void;
}

const PostCard = ({ post, user, onDelete }: PostCardProps) => {
  return (
    <div className="relative">
      <Link
        to={`/posts/${post.username}/${post.id}`}
        className="block mb-6 border rounded shadow p-4 bg-white hover:bg-blue-50 hover:shadow-lg hover:border-blue-400 transition cursor-pointer"
        style={{
          transition: "box-shadow 0.2s, border-color 0.2s, background 0.2s",
        }}
      >
        <div className="text-xl font-semibold mb-1">{post.title}</div>
        <div className="text-gray-700 mb-2">{post.content}</div>
        <div className="text-sm text-gray-500">
          By {post.username} on {new Date(post.createdAt).toLocaleString()}
        </div>
      </Link>
      {user === post.username && (
        <button
          className="absolute top-2 right-2 px-2 py-1 bg-red-500 hover:bg-red-600 text-white rounded text-xs"
          onClick={(e) => {
            e.preventDefault();
            if (onDelete) onDelete();
          }}
        >
          Delete
        </button>
      )}
    </div>
  );
};

export default PostCard;
