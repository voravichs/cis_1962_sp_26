interface BlogCardProps {
  blog: {
    username: string;
    email: string;
    role: string;
  };
  isCurrentUser?: boolean;
}

import { Link } from "react-router-dom";

const BlogCard = ({ blog, isCurrentUser }: BlogCardProps) => (
  <Link
    to={`/posts/${blog.username}`}
    className={`border rounded shadow p-4 bg-white min-w-60 max-w-xs flex-1 transition cursor-pointer ${isCurrentUser ? "ring-2 ring-blue-400" : ""} hover:bg-blue-50 hover:shadow-lg hover:border-blue-400`}
    style={{
      transition: "box-shadow 0.2s, border-color 0.2s, background 0.2s",
    }}
  >
    <div className="text-lg font-semibold mb-1">{blog.username}</div>
    <div className="text-gray-700 mb-1">{blog.email}</div>
  </Link>
);

export default BlogCard;
