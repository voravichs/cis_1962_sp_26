import { useState } from "react";

interface CommentCreateModalProps {
  open: boolean;
  onClose: () => void;
  onCreate: (content: string) => Promise<void>;
}

const CommentCreateModal = ({
  open,
  onClose,
  onCreate,
}: CommentCreateModalProps) => {
  const [content, setContent] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  if (!open) return null;

  const handleSubmit = async (e: React.SubmitEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    try {
      await onCreate(content);
      setSuccess("Comment posted!");
      setContent("");
      setTimeout(() => {
        setSuccess("");
        onClose();
      }, 1000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-md relative">
        <button
          className="absolute top-2 right-2 text-gray-500 hover:text-gray-700 text-3xl cursor-pointer"
          onClick={onClose}
        >
          &times;
        </button>
        <h2 className="text-2xl font-bold mb-4">Post a Comment</h2>
        <form onSubmit={handleSubmit}>
          <textarea
            className="w-full mb-2 p-2 border rounded"
            name="content"
            placeholder="Write your comment..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={4}
            required
          />
          <button
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded cursor-pointer"
            type="submit"
          >
            Post Comment
          </button>
          {error && <div className="text-red-500 mt-2">{error}</div>}
          {success && <div className="text-green-500 mt-2">{success}</div>}
        </form>
      </div>
    </div>
  );
};

export default CommentCreateModal;
