import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { hasToken } from "../util/util";

interface Blog {
  username: string;
  email: string;
  role: string;
}

import BlogCard from "../components/BlogCard";

const Home = () => {
  const [loggedIn, setLoggedIn] = useState(hasToken());
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentBlog, setCurrentBlog] = useState<Blog | null>(null);
  const [error, setError] = useState("");

  // TODO: 
  // Initially fetch blogs and sets the current user if logged in.
  // - This effect should run on initial render and whenever loggedIn state changes.
  // - The result of the fetch request here should filter out the current user's blog and set it separately in the state currentBlog, while the rest of the blogs should be stored in the blogs state variable.
  // - It should also handle the 'loading' state (during the fetch) and 'error' state (if the fetch fails).
  // Hint: You can use the getToken and readUsernameFromToken utility functions to help with authentication and identifying the current user.
  useEffect(() => {
    // Implement me!
  });

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded shadow-md w-full max-w-4xl text-center mb-6">
        <h1 className="text-3xl font-bold mb-4">
          {loggedIn ? "Welcome back to PennBlog!" : "Welcome to PennBlog!"}
        </h1>
        <p className="mb-6 text-gray-700">
          {loggedIn
            ? "Glad to see you again! Explore your blog and check out what others are sharing."
            : "Create, share, and manage your blog posts. Join now to start blogging!"}
        </p>
        {!loggedIn ? (
          <div className="flex justify-center space-x-4">
            <Link
              to="/login"
              className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-6 py-2 rounded transition"
            >
              Login
            </Link>
            <Link
              to="/register"
              className="bg-green-500 hover:bg-green-600 text-white font-semibold px-6 py-2 rounded transition"
            >
              Register
            </Link>
          </div>
        ) : (
          <div>
            <h2 className="text-xl font-bold mb-2">Your Blog</h2>
            {currentBlog && (
              <div className="flex justify-center mb-6">
                <BlogCard blog={currentBlog} isCurrentUser />
              </div>
            )}
            <h2 className="text-xl font-bold mb-2">Other Blogs</h2>
            {error && <div className="text-red-500 mb-2">{error}</div>}
            {loading ? (
              <div className="text-gray-400">Loading blogs...</div>
            ) : blogs.length === 0 ? (
              <div className="text-gray-400">No other blogs found.</div>
            ) : (
              <div
                className="flex flex-wrap gap-4 justify-center overflow-x-auto md:overflow-x-auto md:max-w-full"
                style={{ maxWidth: "100%", paddingBottom: "8px" }}
              >
                {blogs.map((blog) => (
                  <BlogCard key={blog.username} blog={blog} />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;
