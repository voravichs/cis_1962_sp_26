import { useEffect, useState } from "react";

const Profile = () => {
  const [profile, setProfile] = useState({
    username: "",
    email: "",
    role: "",
    description: "",
  });
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState({
    username: "",
    email: "",
    description: "",
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // TODO: Initially load profile
  // - Sends a GET request to /profile with the current user's JWT token
  // - On success, populate the profile state and form state with the returned data
  // - On failure, set an appropriate error message
  // This effect only runs once when the component mounts.
  useEffect(() => {
    // Implement me!
  });

  // TODO: Handle profile update
  // - Sends a PATCH request to /profile with the updated profile data and JWT token
  // - On success, update the profile state, show a success message, and exit edit mode
  // - On failure, show an appropriate error message
  const handleUpdate = async () => {
    // Implement me!
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-6 rounded shadow-md w-96">
        <h2 className="text-2xl font-bold mb-4">Profile</h2>
        {error && <div className="text-red-500 mb-2">{error}</div>}
        {success && <div className="text-green-500 mb-2">{success}</div>}
        {!edit ? (
          <>
            <div className="mb-2">
              <span className="font-semibold">Username:</span>{" "}
              {profile.username}
            </div>
            <div className="mb-2">
              <span className="font-semibold">Email:</span> {profile.email}
            </div>
            <div className="mb-2">
              <span className="font-semibold">Role:</span> {profile.role}
            </div>
            <div className="mb-2">
              <span className="font-semibold">Description:</span>{" "}
              {profile.description || (
                <span className="text-gray-400">No description</span>
              )}
            </div>
            <button
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded mt-4"
              onClick={() => setEdit(true)}
            >
              Update Profile
            </button>
          </>
        ) : (
          <>
            <input
              className="w-full mb-2 p-2 border rounded"
              type="text"
              name="username"
              value={form.username}
              onChange={handleChange}
              placeholder="Username"
            />
            <input
              className="w-full mb-2 p-2 border rounded"
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Email"
            />
            <textarea
              className="w-full mb-2 p-2 border rounded"
              name="description"
              value={form.description}
              onChange={handleChange}
              placeholder="Description"
              rows={3}
            />
            <button
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded mt-2"
              onClick={handleUpdate}
            >
              Save
            </button>
            <button
              className="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded mt-2 ml-2"
              onClick={() => setEdit(false)}
            >
              Cancel
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default Profile;
