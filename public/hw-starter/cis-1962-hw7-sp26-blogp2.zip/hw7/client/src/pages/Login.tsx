import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = ({ onLogin }: { onLogin?: (token: string) => void }) => {
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", password: "" });
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // TODO: Handle form submission for login
  // - Send POST request to /login with form data
  // - On success, store JWT token and currentUser in separate cookies and redirect to home.
  // - Cookies should be set with the following options: { path: '/', secure: true, sameSite: 'strict' }, with an expiration of 1 day.
  // - On failure, display error message
  // You may elect to have a 1 second timeout delay before navigation for a better user experience.
  const handleSubmit = async (e: React.SubmitEvent<HTMLFormElement>) => {
    // Implement me!
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <form
        className="bg-white p-6 rounded shadow-md w-80"
        onSubmit={handleSubmit}
      >
        <h2 className="text-2xl font-bold mb-4">Login</h2>
        <input
          className="w-full mb-2 p-2 border rounded"
          type="text"
          name="username"
          placeholder="Username"
          value={form.username}
          onChange={handleChange}
          required
        />
        <input
          className="w-full mb-2 p-2 border rounded"
          type="password"
          name="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          required
        />
        <button
          className="w-full bg-blue-500 text-white p-2 rounded mt-2"
          type="submit"
        >
          Login
        </button>
        {error && <div className="text-red-500 mt-2">{error}</div>}
        {success && <div className="text-green-500 mt-2">{success}</div>}
      </form>
    </div>
  );
};

export default Login;
