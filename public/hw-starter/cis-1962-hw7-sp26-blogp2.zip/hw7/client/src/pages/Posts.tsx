import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import PostCard from "../components/PostCard";
import PostCreateModal from "../components/PostCreateModal";
import { readUsernameFromToken } from "../util/util";

interface Post {
  id: string;
  title: string;
  content: string;
  username: string;
  createdAt: string;
}

const Posts = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const { user } = useParams<{ user?: string }>();
  const currentUser = readUsernameFromToken();

  // TODO: Handle creating posts
  // - Send POST /posts request to backend with title and content
  // - On success, add the new post to the posts list
  // - On failure, show an error message (using the state error)
  const handleCreate = async (post: { title: string; content: string }) => {
    // Implement me!
  };

  // TODO: Handle loading posts initially and when user changes
  // - Take the user param and make a GET /posts/:user request to load that user's posts
  // - On success, set the posts state with the loaded posts
  // - On failure, show an error message (using the state error)
  // - This effect should also handle loading during the fetch 
  // This effect should also run if the user param changes (e.g. when navigating to a different user's posts)
  useEffect(() => {
    // Implement me!
  });

  // TODO: Handle deleting posts
  // - Send DELETE /posts/:id request to backend with the post id
  // - On success, remove the post from the posts list
  // - On failure, show an error message (using the state error)
  const handleDelete = async (postId: string) => {
    // Implement me!
  };

 return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-2xl">
        <h2 className="text-2xl font-bold mb-4">{user ? `${user}'s Posts` : 'All Posts'}</h2>
        {error && (
          <div className="text-red-500 mb-4">{error}</div>
        )}
        {user === currentUser && (
          <button
            className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded mb-6 cursor-pointer"
            onClick={() => setModalOpen(true)}
          >
            Add Post
          </button>
        )}
        <PostCreateModal
          open={modalOpen}
          onClose={() => setModalOpen(false)}
          onCreate={handleCreate}
        />
        {loading ? (
          <div className="text-gray-500">Loading posts...</div>
        ) : posts.length === 0 ? (
          <div className="text-gray-500">No posts found.</div>
        ) : (
          <div>
            {posts.map(post => (
              <PostCard
                key={post.id}
                post={post}
                user={currentUser}
                onDelete={() => handleDelete(post.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Posts;
