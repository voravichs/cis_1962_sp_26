import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import CommentsSection from "../components/CommentsSection";
import EditPostModal from "../components/EditPostModal";
import { readUsernameFromToken } from "../util/util";

const PostDetail = () => {
  const { user, id } = useParams();
  const [post, setPost] = useState<any>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const currentUser = readUsernameFromToken();

  // TODO: Handle editing posts
  // - Make a PATCH /posts/:id endpoint in the backend, attaching the title and content to be updated
  // - Returns and sets the updated post object on success, or an error message on failure
  const handleEditPost = async (title: string, content: string) => {
    // Implement me!
  };

  // TODO: Handle creating comments
  // - Make a POST /posts/:id/comments endpoint in the backend, attaching the comment content
  // - Returns and adds the new comment to the comments list on success, or an error message on failure
  const handleCreateComment = async (content: string) => {
    // Implement me!
  };

  // TODO: Handle deleting comments
  // - Make a DELETE /posts/:postId/comments/:commentId endpoint in the backend
  // - Removes the comment from the comments list on success, or an error message on failure
  const handleDeleteComment = async (commentId: string) => {
    // Implement me!
  };

  // TODO: Initially load the post AND comments data from the backend
  // - Make a GET /posts/:user/:id endpoint to get the post data, and a GET /posts/:id/comments endpoint to get the comments
  // - Set the post and comments state with the data from the backend, or an error message on failure
  // - Comments should be sorted in reverse chronological order (newest first)
  // This effect should also re-run if the post ID changes (i.e. user navigates to a different post while on this page)
  useEffect(() => {
    // Implement me!
  });

  if (error)
    return (
      <div className="flex justify-center items-center min-h-screen text-red-500">
        {error}
      </div>
    );
  if (!post)
    return (
      <div className="flex justify-center items-center min-h-screen text-gray-500">
        Loading...
      </div>
    );

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-2xl">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-2xl font-bold">{post.title}</h2>
          {user === currentUser && (
            <button
              className="ml-4 px-3 py-1 bg-yellow-400 hover:bg-yellow-500 text-black rounded text-sm cursor-pointer"
              onClick={() => setEditModalOpen(true)}
            >
              Edit Post
            </button>
          )}
        </div>
        <div className="text-gray-700 mb-4">{post.content}</div>
        <div className="text-sm text-gray-500 mb-2">
          By {post.username} on {new Date(post.createdAt).toLocaleString()}
        </div>
        <EditPostModal
          open={editModalOpen}
          onClose={() => setEditModalOpen(false)}
          post={{ title: post.title, content: post.content }}
          onSave={handleEditPost}
        />
        <hr className="my-6 border-black" />
        <CommentsSection
          comments={comments}
          modalOpen={modalOpen}
          setModalOpen={setModalOpen}
          handleCreateComment={handleCreateComment}
          canDeleteComment={user === currentUser}
          handleDeleteComment={handleDeleteComment}
        />
      </div>
    </div>
  );
};

export default PostDetail;
