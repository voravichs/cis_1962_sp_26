# HW6 Blog Part 1 Rubric

## Routes

### Auth Routes
- [ ] POST /register 
    - Create a new user account. 
    - Validates that user input meets the required criteria and that the username is unique within the database. 
    - Hashes the user inputted password before creating a user with the role user.
- [ ] POST /login
    - Log in to an existing user account. 
    - Validates that the username and password are provided
    - Checks that the username exists in the database
    - Compares the provided password with the stored hashed password using bcrypt
    - If the credentials are valid, generates a JWT token that includes the user's username and role, and returns it in the response.

### Profile Routes
- [ ] GET /profile
    - Fetch the profile information for the currently authenticated user. 
    - Excludes the password field from the returned user information.
- [ ] PATCH /profile
    - Updates the profile information for the currently authenticated user. 
    - Partially updates the user's profile fields depending on what is provided in the request body.

### Post Routes
- [ ] POST /posts
    - Create a new blog post for the authenticated user.
    - Uses the defined Post type to create a new post with a provided title and content in the body.
    - Posts include a unique ID created with cuid2.
    - Associates the post with the authenticated user as the author.
- [ ] GET /posts/:user
    - Get all blog posts for the specified user.
    - Route does NOT require authentication.
    - Retrieves a list of all blog posts for the post specified in request parameters.
- [ ] GET /posts/:user/:id
    - Get a specific blog post by its ID for the specified user.
    - Route does NOT require authentication.
    - Retrieves the blog post with the specified ID and for the specified user, both from the request parameters.
- [ ] PATCH /posts/:id
    - Update a specific blog post by its ID for the authenticated user. 
    - Partially updates the post fields depending on what is provided in the request body.
- [ ] DELETE /posts/:id
    - Delete a specific blog post by its ID for the authenticated user.

### Comment Routes
- [ ] POST /posts/:id/comments
    - Create a new comment on a specific blog post by its ID for the authenticated user.
    - Uses the defined Comment type to create a new comment with provided content in the body.
    - Comments include a unique ID created with cuid2.
    - Associates the comment with the authenticated user as the author and the specified post ID.
    - A user is able to comment on their own posts, and other users are able to comment on the posts of other users.
- [ ] GET /posts/:postId/comments
    - Get all comments for a specific blog post by its ID.
    - Results are paginated by the query parameters limit and offset.
    - Route does NOT require authentication.
- [ ] DELETE /posts/:id/comments/:commentId
    - Allows an authenticated user to delete a specific comment on their own post
    - User and post author must match for deletion to be successful.
    - A user is able to delete comments on their own posts, but not comments on the posts of other users.

## Redis Storage

- [ ] User, Post, and Comment data is stored in Redis Cloud.
- [ ] The namespaces used for the data are appropriate and well-structured (e.g., users:{username}, posts:{postId}).

## Auth

- [ ] App properly hashes passwords using bcrypt before storing them in the database.
- [ ] App generates JWT tokens that include the user's username and role upon successful login.
- [ ] App properly verifies JWT tokens for protected routes and extracts user information from the token.

## Code Quality and Error Handling

- [ ] Code follows the provided starter code structure.
- [ ] Any additional scripts written are well-organized, readable, and follows best practices for Express.js applications.
- [ ] Proper error handling is implemented for all routes, with appropriate status codes and error messages as specified in the homework specifications.
- [ ] TypeScript is used effectively, Post and Comment types are used appropriately within the code.
- [ ] No linting errors or warnings are present in the codebase.
