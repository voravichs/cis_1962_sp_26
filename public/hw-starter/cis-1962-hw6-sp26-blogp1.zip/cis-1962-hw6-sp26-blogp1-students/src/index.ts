import express from 'express';
import dotenv from 'dotenv';
// import authRoutes from './routes/authRoutes.ts'
// import profileRoutes from './routes/profileRoutes.ts'
// import postRoutes from './routes/postRoutes.ts'
import redisClient from './config/redis.ts';
dotenv.config();

const app = express();

app.use(express.json());

const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
    res.send('Hello, World!');
});

// app.use(authRoutes)
// app.use(profileRoutes)
// app.use(postRoutes)

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
