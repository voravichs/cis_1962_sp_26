// This file merely makes sure that certain types in the Express Request object are available globally.
// This file should NOT be modified or imported anywhere!

import { JwtPayload } from 'jsonwebtoken';

declare module 'express-serve-static-core' {
  interface Request {
    user?: string | JwtPayload;
  }
}

export type Post = {
  id: string;
  title: string;
  content: string;
  username: string;
  createdAt: string;
};

export type Comment = {
  commentId: string;
  postId: string;
  username: string;
  content: string;
  postAuthor: string | null;
  createdAt: string;
};